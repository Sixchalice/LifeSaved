package com.example.lifesaved.UI;

public interface OnItemClickListener {
    void onItemClick(int index);
}