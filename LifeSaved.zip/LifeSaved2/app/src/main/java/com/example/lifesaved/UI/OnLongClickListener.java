package com.example.lifesaved.UI;

import android.widget.ImageButton;

public interface OnLongClickListener {
//    void onItemLongClick(int index);

    void passImageButton(ImageButton buttonView, int index);
}
